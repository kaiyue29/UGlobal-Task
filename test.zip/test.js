const tasks = [
    { id: 1, title: "Fix login bug", status: "pending", deadline: "2025-05-10" },
    { id: 2, title: "Write unit tests", status: "completed", deadline: "2025-06-01" },
    { id: 3, title: "Update README documentation", status: "pending", deadline: "2025-04-15" },
    { id: 4, title: "Design new user profile page", status: "pending", deadline: "2025-04-01" }
  ];
  
  // Count the number of pending tasks
  function countPendingTasks(taskList) {
    return taskList.filter(task => task.status === "pending").length;
  }
  
  // Get titles of completed tasks
  function getCompletedTaskTitles(taskList) {
    return taskList.filter(task => task.status === "completed").map(task => task.title);
  }
  
  // Sort tasks by deadline (ascending)
  function sortTasksByDeadline(taskList) {
    return [...taskList].sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
  }
  
  // Filter tasks by keyword in title
  function filterTasksByKeyword(taskList, keyword) {
    return taskList.filter(task => task.title.toLowerCase().includes(keyword.toLowerCase()));
  }
  
  // Test the functions
  console.log("Pending tasks:", countPendingTasks(tasks));
  console.log("Completed task titles:", getCompletedTaskTitles(tasks));

  console.log("Sorted tasks by deadline:");
  console.table(sortTasksByDeadline(tasks)); // Displays table format

  console.log("Filtered tasks (keyword 'login'):");
  console.log(JSON.stringify(filterTasksByKeyword(tasks, "login"), null, 2));